
BCCD - v1 2022-01-28 11:10pm
==============================

This dataset was exported via roboflow.ai on January 29, 2022 at 4:11 AM GMT

It includes 320 images.
Cells are annotated in COCO format.

The following pre-processing was applied to each image:
* Resize to 416x416 (Stretch)

No image augmentation techniques were applied.


